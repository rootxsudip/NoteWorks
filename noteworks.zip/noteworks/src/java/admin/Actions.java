package admin;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;

public class Actions extends HttpServlet {

    // Declaring objects
    OracleConnection oconn;
    OraclePreparedStatement ops;

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");

        try (PrintWriter out = res.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Actions</title>");
            out.println(
                    "<link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class=\"container p-3 text-center\">");
            out.println("<h1>Admin Panel</h1>");
            String id = req.getParameter("userId");
            String email = req.getParameter("editedEmail");
            String fname = req.getParameter("editedFullName");
            String dmethod = req.getParameter("delete");
            boolean delete = Boolean.parseBoolean(dmethod);
            String umethod = req.getParameter("update");
            boolean update = Boolean.parseBoolean(umethod);
            int userId = Integer.parseInt(id);
            out.println("<h2>User No : " + userId + "</h2>");
            out.println("<h2>Delete Method: " + delete + "</h2>");
            out.println("<h2>Update Method: " + update + "</h2>");
            if (delete) {
                try {
                    // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                    // INSTANTIATING THE ORACLE CONNECTION OBJECT
                    oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                            "system", "toor");

                    // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                    ops = (OraclePreparedStatement) oconn
                            .prepareCall("DELETE FROM users WHERE ID = ?");

                    // FILLING UP THE BLANK QUERY PARAMETERS (?)
                    ops.setInt(1, userId);

                    // EXECUTING THE QUERY
                    int x = ops.executeUpdate();

                    if (x > 0) {
                        out.println("<h2 style='color:green'> User deleted successfully...");
                    } else {
                        out.println("<h2 style='color:red'> User can't be deleted");
                    }
                    // CLOSING THE ORACLE OBJECTS
                    ops.close();
                    oconn.close();

                }
                // FORMATTING THE CATCH CLAUSE
                catch (SQLException ex) {
                    Logger.getLogger(Actions.class.getName()).log(Level.SEVERE, null, ex);
                    out.println("<h2 style='color:red'> Error is : " + ex.toString() + "</h2>");
                }
                // out.println("Success");
            } else if (update) {
                // out.println("Update code...");
                try {
                    // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                    // INSTANTIATING THE ORACLE CONNECTION OBJECT
                    oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                            "system", "toor");

                    // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                    ops = (OraclePreparedStatement) oconn
                            .prepareCall("UPDATE users SET email = ?,full_name = ? WHERE ID = ?");

                    // FILLING UP THE BLANK QUERY PARAMETERS (?)
                    ops.setString(1, email);
                    ops.setString(2, fname);
                    ops.setInt(3, userId);

                    // EXECUTING THE QUERY
                    int x = ops.executeUpdate();

                    if (x > 0) {
                        out.println("<h2 style='color:green'> User updated successfully...");
                    } else {
                        out.println("<h2 style='color:red'> User can't be updated");
                    }
                    // CLOSING THE ORACLE OBJECTS
                    ops.close();
                    oconn.close();

                }
                // FORMATTING THE CATCH CLAUSE
                catch (SQLException ex) {
                    Logger.getLogger(Actions.class.getName()).log(Level.SEVERE, null, ex);
                    out.println("<h2 style='color:red'> Error is : " + ex.toString() + "</h2>");
                }

            } else {
                out.println("Method not specified");
            }

            out.println(
                    "<h1><a display=\"3\" class=\"btn btn-outline-primary mt-3\" href=\"./dashboard.jsp\">Go to Dashboard</a></h1>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

}
