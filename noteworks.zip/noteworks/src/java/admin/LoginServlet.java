package admin;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;

public class LoginServlet extends HttpServlet {

    // DECLARING ORACLE OBJECTS
    OracleConnection oconn;
    OraclePreparedStatement ops;

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        try {
            // Authenticate the user (replace with your authentication logic)
            String username = req.getParameter("username");
            String password = req.getParameter("password");
            boolean isAuthenticated = performAuthentication(username, password);

            if (isAuthenticated) {
                // Assign the user's role from the database.
                String userRole = getUserRoleFromDatabase(username);

                // Set the user's role in the session.
                HttpSession session = req.getSession();
                session.setAttribute("userRole", userRole);

                // Redirect to a secure page (e.g., the user list page).
                // res.sendRedirect("/admin/userList");
                res.sendRedirect("/noteworks/admin/dashboard.jsp");

                // Get role from session
                // String Role = (String) session.getAttribute("userRole");

                out.println("<title>Login Servlet</title>");
                // String username = req.getParameter("username");
                // out.println("<h1>Hello, " + username + " welcome to the admin panel");
                // out.println("<h1>Role: " + Role);
            } else {
                out.println(
                        "<script>alert('Invalid Credentials');window.location.href='http://localhost:9494/noteworks/admin/';</script>");
            }

        } catch (Exception e) {
            out.println(e);
        }
    }

    private boolean performAuthentication(String username, String password) {
        // Replace with your authentication logic (e.g., database check)
        // return "admin".equals(username) && "admin".equals(password);

        // Oracle database check
        try {
            // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT COUNT(*) FROM admin WHERE username = ? AND password = ?");

            // FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, username);
            ops.setString(2, password);

            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();

            // Check if the query returned a result
            if (result.next() && result.getInt(1) > 0) {
                // User credentials are valid
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        // User credentials are invalid
        return false;
    }

    private String getUserRoleFromDatabase(String username) {
        // Implement logic to retrieve the user's role from the database based on the
        // username.
        // Return the user's role as a String, e.g., "admin" or "user".
        return "admin"; // Replace with the actual role retrieval code.
    }
	
}
