// Desc: 

package ai;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import javax.servlet.*;
import javax.servlet.http.*;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;

public class AISubscription extends HttpServlet{
	
	 // Declaring objects
    OracleConnection oconn;
    OraclePreparedStatement ops;
	
@Override
public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException{
	PrintWriter out = res.getWriter();
	String name = req.getParameter("name");
	String email = req.getParameter("email");
	String address = req.getParameter("address");
	String city = req.getParameter("city");
	String zip = req.getParameter("zip");
	String creditCardName = req.getParameter("creditCardName");
	String cardNum = req.getParameter("cardNum");
	String expiration = req.getParameter("expiration");
	String cvv = req.getParameter("cvv");
	String username = req.getParameter("username");
	
	if(name!=""&& email!="" && address!="" && city!="" && zip!="" && creditCardName!="" && cardNum!="" && expiration!="" && cvv!=""){
//		out.println(name+" "+email+" "+address+" "+city+" "+zip+" "+creditCardName+" "+cardNum+" "+expiration+" "+cvv);
//		out.println(username);
		try{
				    // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                    // INSTANTIATING THE ORACLE CONNECTION OBJECT
                    oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                            "system", "toor");

                    // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                    ops = (OraclePreparedStatement) oconn
                            .prepareCall("update users set subscription = 'True' where email = ?");

                    // FILLING UP THE BLANK QUERY PARAMETERS (?)
                    ops.setString(1, username);

                    // EXECUTING THE QUERY
					int x = ops.executeUpdate();

                    // CLOSING THE ORACLE OBJECTS
                    ops.close();
                    oconn.close();
					
					out.println("Thanks for purchasing subscription");
		}catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
        }
	}
	
}
}
