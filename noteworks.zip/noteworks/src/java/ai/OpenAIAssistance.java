// Desc: 

package ai;


import java.io.IOException;
import java.io.PrintWriter;
import java.lang.System;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

public class OpenAIAssistance extends HttpServlet {
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		 res.setContentType("text/html; charset=UTF-8");
         PrintWriter out = res.getWriter();
		 String searchTerm = req.getParameter("search");
		 String askmethod = req.getParameter("askmethod");
		 
//		 If the api request with searchterm it gives other user req/res
//		 String PotentialIssue = "{\n    \"model\": \"gpt-3.5-turbo-instruct\",\n    \"prompt\": \"searchterm\", \"max_tokens\":1000}";
		 String shortSummaryJson = "{\n  \"model\": \"gpt-3.5-turbo-instruct\",\n  \"prompt\": \"make a short note about: test\", \"max_tokens\":1000}";
		 String questionsJson = "{\n  \"model\": \"gpt-3.5-turbo-instruct\",\n  \"prompt\": \"Generate questions on the following text: test\", \"max_tokens\":1000}";
		 String ansJson = "{\n  \"model\": \"gpt-3.5-turbo-instruct\",\n  \"prompt\": \"test\", \"max_tokens\":1000}";
//		 String userQueryJson =  generateJsonRequest(searchTerm,shortSummaryJson);
		 
         // Replace YOUR_API_KEY with your actual OpenAI API key
		 String apiKey = System.getenv("apiKey");
//	     out.println("Hello");
		 

	if(askmethod.contains("shortNote"))
	{
		 String userQueryJson =  generateJsonRequest(searchTerm,shortSummaryJson);
	     //Chat Completion of Summary
		 HttpClient client = HttpClient.newHttpClient();

		  HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://api.openai.com/v1/completions"))
            .POST(BodyPublishers.ofString(userQueryJson))
            .setHeader("Content-Type", "application/json")
            .setHeader("Authorization", "Bearer "+apiKey)
            .build();

		try {
			HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

			String aiRes = extractText(response.body());
//			out.println(classPath);
			out.println(aiRes);
				
		} catch (InterruptedException ex) {
			Logger.getLogger(OpenAIAssistance.class.getName()).log(Level.SEVERE, null, ex);
		}		
	}else if(askmethod.contains("questions"))
	{
//		String filterText = searchTerm.replace("\"","");
		 String userQueryJson =  generateJsonRequest(searchTerm,questionsJson);
	     //Chat Completion of Summary
		 HttpClient client = HttpClient.newHttpClient();

		  HttpRequest questionsRequest = HttpRequest.newBuilder()
            .uri(URI.create("https://api.openai.com/v1/completions"))
            .POST(BodyPublishers.ofString(userQueryJson))
            .setHeader("Content-Type", "application/json")
            .setHeader("Authorization", "Bearer "+apiKey)
            .build();

		try {
			HttpResponse<String> questionsResponse = client.send(questionsRequest, HttpResponse.BodyHandlers.ofString());

			String aiRes = extractText(questionsResponse.body());
			out.println(aiRes);
//			out.println(userQueryJson);
//			out.println(questionsResponse.body());
				
		} catch (InterruptedException ex) {
			Logger.getLogger(OpenAIAssistance.class.getName()).log(Level.SEVERE, null, ex);
		}		
	}
	else if(askmethod.contains("answer"))
	{
//		String filterText = searchTerm.replace("\"","");
		 String userQueryJson =  generateJsonRequest(searchTerm,ansJson);
	     //Chat Completion of Summary
		 HttpClient client = HttpClient.newHttpClient();

		  HttpRequest ansRequest = HttpRequest.newBuilder()
            .uri(URI.create("https://api.openai.com/v1/completions"))
            .POST(BodyPublishers.ofString(userQueryJson))
            .setHeader("Content-Type", "application/json")
            .setHeader("Authorization", "Bearer "+apiKey)
            .build();

		try {
			HttpResponse<String> ansResponse = client.send(ansRequest, HttpResponse.BodyHandlers.ofString());

			String aiRes = extractText(ansResponse.body());
			out.println(aiRes);
//			out.println(userQueryJson);
//			out.println(ansResponse.body());
				
		} catch (InterruptedException ex) {
			Logger.getLogger(OpenAIAssistance.class.getName()).log(Level.SEVERE, null, ex);
		}		
	}
}
	 public static String generateJsonRequest(String searchTerm,String jsonString) {
        // Check if the search term is null or empty
        if (searchTerm == null || searchTerm.isEmpty()) {
            throw new IllegalArgumentException("Search term cannot be null or empty.");
        }

        // Check if the length of the search term is within a valid range
        int searchTermLength = searchTerm.length();
        if (searchTermLength < 2 || searchTermLength > 5000) {
            throw new IllegalArgumentException("Search term length should be between 3 and 5000 characters.");
        }

        // Your original JSON string
        String originalJson = jsonString;

        // Replace "searchTerm" with the variable value
        return originalJson.replace("test", searchTerm);
    }
	 
	public static String extractText(String res){
		 JSONObject jsonObject = new JSONObject(res);
 
         // Get choices array
		 JSONArray choicesArray = jsonObject.getJSONArray("choices");
    
            if (choicesArray.length() > 0) {
                // Extracting "text" value from the first element in choices
                JSONObject firstChoice = choicesArray.getJSONObject(0);
                String textValue = firstChoice.getString("text");
				String modify = textValue.replace("\n", "<br>");
				String aiRes = modify.replace("<br><br>", "<br>");
			
                return aiRes;
                }
			return null;
	}
}
