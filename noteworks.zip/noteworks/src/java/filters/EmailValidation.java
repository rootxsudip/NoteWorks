// Desc: 

package filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;

public class EmailValidation {

	// DECLARING ORACLE OBJECTS
    OracleConnection oconn;
    OraclePreparedStatement ops;

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        try {
            // Authenticate the user (replace with your authentication logic)
            String email = req.getParameter("email");
            boolean isValidEmail = emailCheck(email);

            if (isValidEmail) {
               res.sendRedirect("/noteworks/ForgetPassword");
            } else {
                out.println(
                        "<script>alert('Email not registered');window.location.href='http://localhost:9494/noteworks/';</script>");
            }

        } catch (Exception e) {
            out.println(e);
        }
    }

    private boolean emailCheck(String email) {
        // Replace with your authentication logic (e.g., database check)
        // return "admin".equals(username) && "admin".equals(password);

        // Oracle database check
        try {
            // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT COUNT(*) FROM users WHERE email = ?");

            // FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, email);

            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();

            // Check if the query returned a result
            if (result.next() && result.getInt(1) > 0) {
                // User credentials are valid
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        // User credentials are invalid
        return false;
    }
}
