// Desc: 

package filters;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SubscriptionFilter implements Filter {
@Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Pre-process the request
        HttpServletRequest req = (HttpServletRequest) request; // Type casted the ServletRequest to HttpServletRequest
        HttpServletResponse res = (HttpServletResponse) response; // Type casted the ServletRequest to
                                                                  // HttpServletRequest

        HttpSession session = req.getSession();
        String subscription = (String) session.getAttribute("subscription");

        if (subscription != null) {
            // If the subscription is true allow the request to proceed.
            // Forward the request
            chain.doFilter(request, response);

        } else { // Redirect normal users to a notes page.
//            res.sendRedirect("/noteworks/payment"); //
			res.setStatus(403);
        }

        // Post Processing code
        System.out.println("Subscription filter");
    }
}
