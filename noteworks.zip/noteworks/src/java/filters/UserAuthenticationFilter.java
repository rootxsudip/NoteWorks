package filters;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UserAuthenticationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Pre-process the request
        HttpServletRequest req = (HttpServletRequest) request; // Type casted the ServletRequest to HttpServletRequest
        HttpServletResponse res = (HttpServletResponse) response; // Type casted the ServletRequest to
                                                                  // HttpServletRequest

        HttpSession session = req.getSession();
        String userRole = (String) session.getAttribute("userRole");

        if (userRole != null && userRole.equals("user")) {
            // The user is authenticated as an admin, so allow the request to proceed.
            // Forward the request
            chain.doFilter(request, response);

        } else { // Redirect unauthenticated users to a login page or display an error.
            res.sendRedirect("/noteworks/"); // Adjust the login page URL as needed.
        }

        // Post Processing code
        System.out.println("After filter");
    }

}
