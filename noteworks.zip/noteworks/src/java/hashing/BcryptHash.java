package hashing;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class BcryptHash {
    public static String gensalt() throws NoSuchAlgorithmException {
        // Generate a random salt for the user
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        String userSalt = new String(salt); // Convert the byte array to a string or use a different method based on
                                            // your preference or get the salt from db
        return userSalt;
    }

    public static String genHashPass(String userPassword, String userSalt) {
        // Concatenate the user's password and salt before hashing
        String passwordWithSalt = userPassword + userSalt;
        String hashedPassword = BCrypt.hashpw(passwordWithSalt, BCrypt.gensalt());
        return hashedPassword;
    }

    public static boolean checkPass(String userPassword, String userSalt, String hashedPassword) {
        // Concatenate the entered password and stored salt for verification
        String StoredUserSalt = userSalt; // Get Salt from db
        String UserEnteredPasswordWithSalt = userPassword + StoredUserSalt;
        // Hash the entered password with the stored salt and compare it with the stored
        // hash
        if (BCrypt.checkpw(UserEnteredPasswordWithSalt, hashedPassword)) {
            // Passwords match, user is authenticated
            // Proceed with the login logic
            return true;
        } else {
            // Passwords do not match, login is invalid
            // Handle the login error accordingly
            return false;
        }
    }
}
