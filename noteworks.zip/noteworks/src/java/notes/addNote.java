// Desc: 

package notes;

import admin.Actions;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;

public class addNote extends HttpServlet {
	
	 // Declaring objects
    OracleConnection oconn;
    OraclePreparedStatement ops;
	
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        // Retrieve note ID from the request
		String note_heading= request.getParameter("heading");
		String content = request.getParameter("content");
		String email = request.getParameter("email");
        // Use a service or DAO class to fetch the note content based on the note ID
//        NoteService noteService = new NoteService(); // You should replace this with your actual service class
//        String noteContent = noteService.getNoteContentById(noteId);

		try {
                    // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                    // INSTANTIATING THE ORACLE CONNECTION OBJECT
                    oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                            "system", "toor");

                    // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                    ops = (OraclePreparedStatement) oconn
                            .prepareCall("INSERT INTO notes (note_heading, content, user_email) VALUES (?, ?, ?)");

                    // FILLING UP THE BLANK QUERY PARAMETERS (?)
                    ops.setString(1, note_heading);
                    ops.setString(2, content);
                    ops.setString(3, email);

                    // EXECUTING THE QUERY
					int x = ops.executeUpdate();

//                   if (x > 0) {
//                    String dest_reg = "/noteworks/notes";
//                    response.sendRedirect(request.getContextPath() + dest_reg);
//					} 
				   
				    // Send the note content as the response
//					response.setContentType("text/html;charset=UTF-8");
//					response.setCharacterEncoding("UTF-8");
//					PrintWriter out = response.getWriter();
//					out.write(note_heading);
//					
                    // CLOSING THE ORACLE OBJECTS
                    ops.close();
                    oconn.close();

                }
		catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
        }
    }
  }
