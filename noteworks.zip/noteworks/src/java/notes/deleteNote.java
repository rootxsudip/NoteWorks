// Desc: 

package notes;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;
import user.register;

public class deleteNote extends HttpServlet {
	
	 // Declaring objects
    OracleConnection oconn;
    OraclePreparedStatement ops;
	
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
		
		PrintWriter out = response.getWriter();
        // Retrieve note ID from the request
		String noteId = request.getParameter("noteId");
		String email = request.getParameter("email");
        // Use a service or DAO class to fetch the note content based on the note ID
//        NoteService noteService = new NoteService(); // You should replace this with your actual service class
//        String noteContent = noteService.getNoteContentById(noteId);

		try {
                    // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                    // INSTANTIATING THE ORACLE CONNECTION OBJECT
                    oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                            "system", "toor");

                    // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                    ops = (OraclePreparedStatement) oconn
                            .prepareCall("delete from notes where note_id = ? and user_email = ?");

                    // FILLING UP THE BLANK QUERY PARAMETERS (?)
                    ops.setString(1, noteId);
                    ops.setString(2, email);

                    // EXECUTING THE QUERY
					int x = ops.executeUpdate();

                   if (x > 0) {
//                    String dest_reg = "/noteworks/notes";
//                    response.sendRedirect(request.getContextPath() + dest_reg);
//					  out.println("Success");
					} 
				   
				    // Send the note content as the response
//					response.setContentType("text/html;charset=UTF-8");
//					response.setCharacterEncoding("UTF-8");
//					PrintWriter out = response.getWriter();
//					out.write(note_heading);
//					
                    // CLOSING THE ORACLE OBJECTS
                    ops.close();
                    oconn.close();

                }
		// FORMATTING THE CATCH CLAUSE
            catch (SQLException ex) {
//                dest_error = "/static/reg-error.html";
//                response.sendRedirect(request.getContextPath() + dest_error);
//                Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                out.println("<h2 style='color:red'> Error is : " + ex.toString() + "</h2>");
            }
    }
  }
