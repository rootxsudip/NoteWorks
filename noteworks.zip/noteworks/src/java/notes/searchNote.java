// Desc: 

package notes;

import admin.Actions;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;


public class searchNote extends HttpServlet {
	
	 // Declaring objects
    OracleConnection oconn;
    OraclePreparedStatement ops;
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
		 PrintWriter out = response.getWriter();
				
		 String searchTerm = request.getParameter("search");
//		 out.print(searchTerm);
		 
		//db code
		try {
                    // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                    // INSTANTIATING THE ORACLE CONNECTION OBJECT
                    oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                            "system", "toor");

                    // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                    ops = (OraclePreparedStatement) oconn
                            .prepareCall("SELECT note_heading,content,note_id FROM notes  where instr(lower(note_heading),?) >= 1 order by note_id");

                    // FILLING UP THE BLANK QUERY PARAMETERS (?)
                    ops.setString(1, searchTerm);

                    // EXECUTING THE QUERY
                    ResultSet result = ops.executeQuery();

                    // Check if the query returned a result
					List<Note> data = new ArrayList<>();
					while (result.next()) {
						  // Creating a list of JavaScript objects (in Java)
						 data.add(new Note(result.getString(1), result.getString(2),result.getInt(3)));

						
					 }
//					data.add(new Note("test", searchTerm));
					// Converting the list to JSON
					String jsonData = new Gson().toJson(data);
					
					// Setting the content type and encoding for the response
					response.setContentType("application/json");
					response.setCharacterEncoding("UTF-8");
					
					// Writing the JSON data to the response PrintWriter
					out.print(jsonData);
					
                    // CLOSING THE ORACLE OBJECTS
                    ops.close();
                    oconn.close();

                }
                // FORMATTING THE CATCH CLAUSE
                catch (SQLException ex) {
                    Logger.getLogger(Actions.class.getName()).log(Level.SEVERE, null, ex);
                    out.println("<h2 style='color:red'> Error is : " + ex.toString() + "</h2>");
                }
		
      
    }

    // Sample class representing a JavaScript object
    private static class Note {
        private String heading;
        private String body;
		private int note_id;

        public Note(String itemName, String itemDescription, int id) {
            this.heading = itemName;
            this.body = itemDescription;
			this.note_id = id;
        }
    }
}

