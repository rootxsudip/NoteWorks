// Desc: 
package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.Random;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;

public class ForgetPassword extends HttpServlet {
	
	// DECLARING ORACLE OBJECTS
    OracleConnection oconn;
    OraclePreparedStatement ops;

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
//	out.println("Hello from ForgetPassword Servlet.");
		String email = req.getParameter("email");
		RequestDispatcher dispatcher = null;
		int otpvalue = 0;
		HttpSession mySession = req.getSession();
		
		//Checking email
		if (email != null) {
            // sending otp
            Random rand = new Random();
            otpvalue = rand.nextInt(1255650);

            String to = email;// change accordingly
			boolean isValidEmail = emailCheck(email);
			if(isValidEmail){
				// Get the session object
				Properties props = new Properties();
				props.put("mail.smtp.host", "smtp.gmail.com");
				props.put("mail.smtp.socketFactory.port", "465");
				props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
				props.put("mail.smtp.auth", "true");
				props.put("mail.smtp.port", "465");
				Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication("rootxsudip@gmail.com", "wcadlebuqdddornv ");// Put your email
						// id and
						// password here
					}
				});
				// compose message
				try {
					MimeMessage message = new MimeMessage(session);
					message.setFrom(new InternetAddress(email));// change accordingly
					message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
					message.setSubject("Password Reset Request from NoteWorks");
					message.setText("Your OTP is: " + otpvalue);
					// send message
					Transport.send(message);
					System.out.println("message sent successfully");
				}

				catch (MessagingException e) {
					throw new RuntimeException(e);
				}
				dispatcher = req.getRequestDispatcher("/forget-password/otp.jsp");
				req.setAttribute("message", "Your OTP is send to "+email);
				// request.setAttribute("connection", con);
				mySession.setAttribute("otp", otpvalue);
				mySession.setAttribute("email", email);
				dispatcher.forward(req, res);
				// request.setAttribute("status", "success");
			}else{
				 out.println("<script>alert('Email not registered');window.location.href='http://localhost:9494/noteworks/';</script>");
			}
			
        }
	}
	
	private boolean emailCheck(String email) {
        // Replace with your authentication logic (e.g., database check)
        // return "admin".equals(username) && "admin".equals(password);

        // Oracle database check
        try {
            // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT COUNT(*) FROM users WHERE email = ?");

            // FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, email);

            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();

            // Check if the query returned a result
            if (result.next() && result.getInt(1) > 0) {
                // User credentials are valid
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        // User credentials are invalid
        return false;
    }
}
