// Desc: 
package user;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;
import hashing.BcryptHash;
import java.security.NoSuchAlgorithmException;
import java.sql.DriverManager;
import java.sql.SQLException;

public class PasswordReset extends HttpServlet {

	String email, password,cpassword, hashedPassword, UserSalt, dest_reg, dest_error;

	// DECLARING ORACLE OBJECTS
	OracleConnection oconn;
	OraclePreparedStatement ops;

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/html;charset=UTF-8");
		try ( PrintWriter out = res.getWriter()) {
//			out.println("Hello from PasswordReset Servlet");
			HttpSession session = req.getSession();
			password = req.getParameter("password");
			cpassword = req.getParameter("cpassword");
			email = (String) session.getAttribute("email");

			if (password != null && cpassword != null && password.equals(cpassword)) {

				// Password Hashing
				try {
					UserSalt = BcryptHash.gensalt();
				} catch (NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				hashedPassword = BcryptHash.genHashPass(password, UserSalt);
//				out.println("Email: "+email);
//				out.println("UserPassword: "+password);
//				out.println("UserCPassword: "+cpassword);
//				out.println("Usersalt: " + UserSalt + " HashedPass: " + hashedPassword);

				//DB Work
				try {
					// REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
					DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

					// THE ORACLE CONNECTION OBJECT
					oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
							"system", "toor");

					// INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
					ops = (OraclePreparedStatement) oconn
							.prepareCall("update USERS set PASS = ?, USER_SALT = ? where email = ? ");

					// STEP 6: FILLING UP THE BLANK QUERY PARAMETERS (?)
					ops.setString(1, hashedPassword);
					ops.setString(2, UserSalt);
					ops.setString(3, email);

					// STEP 7: EXECUTING THE QUERY
					int x = ops.executeUpdate();

					if (x > 0) {
						dest_reg = "/static/password-reset.html";
						res.sendRedirect(req.getContextPath() + dest_reg);
						out.println("<h2 style='color:green'> Record inserted successfully...");
					} else {
						out.println("<h2 style='color:red'> Some problem occured contact support.");
					}

					// STEP 8: CLOSING THE ORACLE OBJECTS
					ops.close();
					oconn.close();

				} // FORMATTING THE CATCH CLAUSE
				catch (SQLException ex) {
					dest_error = "/static/pass-reset-error.html";
					out.println("<h2 style='color:red'> Error is : " + ex.toString() + "</h2>");
				}

			} else {
				res.sendRedirect("/noteworks");
			}

		}
	}
}
