package user;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;
import hashing.BcryptHash;
import java.sql.SQLException;

public class login extends HttpServlet {

    // DECLARING ORACLE OBJECTS
    OracleConnection oconn;
    OraclePreparedStatement ops;

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        try {
            // Authenticate the user (replace with your authentication logic)
            String username = req.getParameter("email");
            String password = req.getParameter("password");
            boolean isAuthenticated = performAuthentication(username, password);

            if (isAuthenticated) {
                // Assign the user's role from the database.
                String userRole = getUserRoleFromDatabase(username);
				String subscription = getSubscriptionStatus(username);
				String name = getName(username);
				String image = getImage(username);

                // Set the user's role in the session.
                HttpSession session = req.getSession();
                session.setAttribute("userRole", userRole);
                session.setAttribute("email", username);
                session.setAttribute("subscription", subscription);
                session.setAttribute("name", name);
                session.setAttribute("image", image);

                res.sendRedirect("/noteworks/notes/");

            }
			else {
                out.println(
                        "<script>alert('Invalid Credentials');window.location.href='http://localhost:9494/noteworks/';</script>");
            }

        } catch (Exception e) {
            out.println(e);
        }
    }

    private boolean performAuthentication(String username, String password) {
        // Replace with your authentication logic (e.g., database check)
        // return "admin".equals(username) && "admin".equals(password);

        // Oracle database check
        try {
            // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT pass,user_salt,full_name FROM users WHERE email = ?");

            // FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, username);

            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();

            // Check if the query returned a result
            if (result.next()) {
                String hashedPassword = result.getString("pass");
                String salt = result.getString("user_salt");
                if (BcryptHash.checkPass(password, salt, hashedPassword)) {
                    return true;
                }
            }

        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        // User credentials are invalid
        return false;
    }

    private String getUserRoleFromDatabase(String username) {
        // Implement logic to retrieve the user's role from the database based on the
        // username.
        // Return the user's role as a String, e.g., "admin" or "user".
        return "user"; // Replace with the actual role retrieval code.
    }
	private String getSubscriptionStatus(String username) throws SQLException {
        // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT subscription FROM users WHERE email = ?");

			// FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, username);
			
            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();
			
			String status="";
			 // Check if the query returned a result
            if (result.next()) {
               status = result.getString("subscription");
			   return status;
            }
			return null;
    }
	private String getName(String username) throws SQLException {
        // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT full_name FROM users WHERE email = ?");

			// FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, username);
			
            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();
			
			String name="";
			 // Check if the query returned a result
            if (result.next()) {
               name = result.getString("full_name");
			   return name;
            }
			return null;
    }
	private String getImage(String username) throws SQLException {
        // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT image FROM users WHERE email = ?");

			// FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, username);
			
            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();
			
			String image="";
			 // Check if the query returned a result
            if (result.next()) {
               image = result.getString("image");
			   return image;
            }
			return null;
    }
}
