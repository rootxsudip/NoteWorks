package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;
import hashing.BcryptHash;
import java.security.NoSuchAlgorithmException;


public class profile extends HttpServlet {
// DECLARING ORACLE OBJECTS
    OracleConnection oconn;
    OraclePreparedStatement ops;
String hashedPassword, UserSalt;
protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();;
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String oldEmail = req.getParameter("oldEmail");
		String password = req.getParameter("password");
		
		// Password Hashing
				try {
					UserSalt = BcryptHash.gensalt();
				} catch (NoSuchAlgorithmException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				hashedPassword = BcryptHash.genHashPass(password, UserSalt);
				
		int id = -1;
		try {
			id = getUserId(oldEmail);
		} catch (SQLException ex) {
			Logger.getLogger(profile.class.getName()).log(Level.SEVERE, null, ex);
		}
		out.println(name+" "+email+" "+oldEmail+" "+id+" "+password+" "+hashedPassword+" "+UserSalt);
		if(id!=-1){
			try{
				// REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                    // INSTANTIATING THE ORACLE CONNECTION OBJECT
                    oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                            "system", "toor");

                    // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                    ops = (OraclePreparedStatement) oconn
                            .prepareCall("update users set email = ?, full_name= ?,PASS = ?, USER_SALT = ? where id = ?");
					
                    // FILLING UP THE BLANK QUERY PARAMETERS (?)
                    ops.setString(1, email);
                    ops.setString(2, name);
					ops.setString(3, hashedPassword);
					ops.setString(4, UserSalt);
					ops.setInt(5, id);

                    // EXECUTING THE QUERY
					int x = ops.executeUpdate();
					
					// CLOSING THE ORACLE OBJECTS
                    ops.close();
                    oconn.close();
					
//					change email in note database
					try{
					changeNotesEmail(email,oldEmail);
					}catch (Exception e) {
								out.println("...");
					}
					
					
					out.println("Success");
			}catch (SQLException ex) {
			out.println("<h2 style='color:red'> Error is : " + ex.toString() + "</h2>");
            res.setStatus(403); // give 403 when error occured
        }
		}
		
        }
	private int getUserId(String username) throws SQLException {
        // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT id FROM users WHERE email = ?");

			// FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, username);
			
            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();
			
			int id;
			 // Check if the query returned a result
            if (result.next()) {
               id = result.getInt("id");
			   return id;
            }
			return -1;
    }
	
	private void changeNotesEmail(String email,String oldEmail) throws SQLException {
        // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("update notes set user_email = ? where user_email = ?");

			// FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, email);
            ops.setString(2, oldEmail);
			
			// EXECUTING THE QUERY
			int x = ops.executeUpdate();
					
			// CLOSING THE ORACLE OBJECTS
            ops.close();
            oconn.close();
    }
	
}

