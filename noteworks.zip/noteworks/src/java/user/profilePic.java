// Desc: 

package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;

public class profilePic extends HttpServlet {
  // DECLARING ORACLE OBJECTS
    OracleConnection oconn;
    OraclePreparedStatement ops;

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();
        String image = req.getParameter("image");
		
		// Get the session from the request
        HttpSession session = req.getSession();
		String email = (String) session.getAttribute("email");
		
		//Set user pfp in db
		try{
			// REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                    DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                    // INSTANTIATING THE ORACLE CONNECTION OBJECT
                    oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                            "system", "toor");

                    // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                    ops = (OraclePreparedStatement) oconn
                            .prepareCall("update users set image = ? where email = ?");
					
                    // FILLING UP THE BLANK QUERY PARAMETERS (?)
					ops.setString(1, image);;
                    ops.setString(2, email);

                    // EXECUTING THE QUERY
					int x = ops.executeUpdate();
					
					// CLOSING THE ORACLE OBJECTS
                    ops.close();
                    oconn.close();
					
					out.println("Success");
		}catch (SQLException ex) {
			out.println("<h2 style='color:red'> Error is : " + ex.toString() + "</h2>");
            res.setStatus(403); // give 403 when error occured
        }

    }
}
