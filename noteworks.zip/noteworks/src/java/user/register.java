package user;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OraclePreparedStatement;
import hashing.BcryptHash;
import java.sql.ResultSet;

public class register extends HttpServlet {
    String name, email, pass, hashedPassword, UserSalt, dest_reg, dest_error;

    // STEP 1: DECLARING ORACLE OBJECTS
    OracleConnection oconn;
    OraclePreparedStatement ops;

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Register</title>");
            out.println("<body>");
            name = request.getParameter("tbName");
            email = request.getParameter("tbEmail");
            pass = request.getParameter("tbPass");

			if(!userExists(email)){
            // Password Hashing
            try {
                UserSalt = BcryptHash.gensalt();
            } catch (NoSuchAlgorithmException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            hashedPassword = BcryptHash.genHashPass(pass, UserSalt);
            // out.println("Usersalt: " + UserSalt + " HashedPass: " + hashedPassword);
            out.println("<h2>Thank you " + name + " for registering" + "</h2>");

            try {
                // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
                DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

                // THE ORACLE CONNECTION OBJECT
                oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl",
                        "system", "toor");

                // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
                ops = (OraclePreparedStatement) oconn
                        .prepareCall("INSERT INTO USERS(EMAIL,FULL_NAME,PASS,USER_SALT) values(?,?,?,?)");

                // STEP 6: FILLING UP THE BLANK QUERY PARAMETERS (?)
                ops.setString(1, email);
                ops.setString(2, name);
                ops.setString(3, hashedPassword);
                ops.setString(4, UserSalt);

                // STEP 7: EXECUTING THE QUERY
                int x = ops.executeUpdate();

                if (x > 0) {
                    dest_reg = "/static/thanks.html";
                    response.sendRedirect(request.getContextPath() + dest_reg);
                    out.println("<h2 style='color:green'> Record inserted successfully...");
                } else {
                    out.println("<h2 style='color:brown'> Record could not be added...");
                }

                // STEP 8: CLOSING THE ORACLE OBJECTS
                ops.close();
                oconn.close();

            }

            // FORMATTING THE CATCH CLAUSE
            catch (SQLException ex) {
                dest_error = "/static/reg-error.html";
                response.sendRedirect(request.getContextPath() + dest_error);
                Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                out.println("<h2 style='color:red'> Error is : " + ex.toString() + "</h2>");
            }

            out.println("</head>");
            out.println("</body>");
            out.println("</html>");
        }else{
				out.println("<script>alert('User already exists!!');window.location.href='/noteworks'</script>");
			}
		}
    }
	public static boolean userExists(String email){
		// DECLARING ORACLE OBJECTS
		OracleConnection oconn;
		OraclePreparedStatement ops;

		// Oracle database check
        try {
            // REGISTERING THE ORACLE DRIVER WITH THIS SERVLEt
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

            // INSTANTIATING THE ORACLE CONNECTION OBJECT
            oconn = (OracleConnection) DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.7:1521:orcl", "system",
                    "toor");

            // INSTANTIATING THE ORACLE PREPARED STATEMENT OBJECT
            ops = (OraclePreparedStatement) oconn
                    .prepareCall("SELECT COUNT(*) FROM users WHERE email = ?");

            // FILLING UP THE BLANK QUERY PARAMETERS (?)
            ops.setString(1, email);

            // EXECUTING THE QUERY
            ResultSet result = ops.executeQuery();

            // Check if the query returned a result
            if (result.next() && result.getInt(1) > 0) {
                // User credentials are valid
                return true;
            }

        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception appropriately
        }

        // User credentials are invalid
        return false;
	}

}