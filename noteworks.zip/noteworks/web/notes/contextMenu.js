const contextMenu = document.querySelector(".contextMenu-wrapper")
const closeMenu =  document.querySelector("#close-menu")

document.addEventListener("contextmenu",e=>{
//    console.log("Right Clicked")
      e.preventDefault()
      
      let x = e.offsetX, y = e.offsetY;
      winWidth = window.innerWidth
      cmWidth = contextMenu.offsetWidth
      
      x = x > winWidth - cmWidth ? winWidth - cmWidth : x
      contextMenu.style.left = `${x}px`
      contextMenu.style.top = `${y}px`
      contextMenu.style.visibility = "visible"
})

closeMenu.addEventListener("click",e=>{
      contextMenu.style.visibility = "hidden"
})