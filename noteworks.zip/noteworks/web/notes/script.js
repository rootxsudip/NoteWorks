const sidebar = document.querySelector(".sidebar");
const addNote = document.querySelector(".addNote");
const textarea = document.querySelector(".user_text");
const save = document.querySelector(".save");
const dropbtn = document.querySelector(".profile");
const dropdown = document.querySelector(".info");
const closeBtn = document.querySelector(".close-btn");
let notes = document.querySelector(".notes");
const container = document.querySelector(".container");
const popup = document.querySelector(".popup");
const addTitle = document.querySelector(".addTitle");
const closePopup = document.querySelector(".close-btn2");
let titleInput = document.querySelector("#title");
let del = document.createElement("i");
let textzone = document.createElement("textarea");
let deleteNotes = document.querySelectorAll(".crossNote");
const search_bar = document.querySelector(".search-bar");
const submit_search = document.querySelector(".submit_search");
const open_search = document.querySelector(".open_search");
const search_input = document.querySelector(".search_input");
const AIContent = document.querySelector('.AIContent')

//Select text in textarea
function selectText() {
    const selectedText = textarea.value.substring(textarea.selectionStart,textarea.selectionEnd);
    return selectedText
}

function getIdOnClick(element) {
           var elementId = element.id;
           localStorage.setItem('isActive', elementId);
}

//Search bar
search_bar.addEventListener("click", function () {
  search_bar.classList.add("activeSearchBar");
  open_search.style.display = "none";
  submit_search.style.display = "block";
  open_search.style.display = "none";
  search_input.style.display = "block";
});
document.addEventListener("click", (e) => {
  if (e.target.className === "container" || e.target.className === "header") {
    search_bar.classList.remove("activeSearchBar");
    dropdown.style.display = "none";
    search_bar.style.opacity = 0.9;
    submit_search.style.display = "none";
    open_search.style.display = "block";
    search_input.style.display = "none";
  }
  var elems = document.querySelector(".active");
    if(elems !=null) {
      elems.classList.remove("active");
    }
  item="#"+localStorage.getItem('isActive')
  document.querySelector(item).classList.add('active');
});

dropbtn.addEventListener("click", function(){
    dropdown.style.display = "flex";
})

closeBtn.addEventListener("click", function(){
    dropdown.style.display = "none";
})

addNote.addEventListener("click", function(){
    popup.style.display = "block";
})

addTitle.addEventListener("click", (e)=>{
    e.preventDefault();
    if(titleInput.value!==""){
    popup.style.display = "none";
    textzone.setAttribute("contenteditable", "true");
    textzone.className = "textzone";
    container.appendChild(textzone);
    let a = document.createElement('a');
    let link = document.createTextNode(`${titleInput.value}`);
    a.appendChild(link);
    a.href = `#${titleInput.value}`;
    del.className = "ri-close-circle-line crossNote";
    notes.appendChild(a).appendChild(del);
    textarea.value = "";
//    if(del.addEventListener("click", removeNote)){
//    function removeNote(e){
//            e.target.parentElement.remove();
//            updateStorage();
//            }
//        }
    }
console.log(titleInput.value)
let noteHeading = titleInput.value
let email = localStorage.getItem('email');
var params = "heading=" + encodeURIComponent(noteHeading) + "&content=" + encodeURIComponent("") + "&email=" + encodeURIComponent(email);
 var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var noteContent = xhr.responseText;
                window.location.href = "/noteworks/notes";
//                showNoteContent(noteId, noteContent);
              }
            };
            xhr.open("POST", "AddNote", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.send(params);
//window.location.href = "/noteworks/notes";    
});

function updateStorage() {
  localStorage.setItem("textzone", textarea.innerHTML);
}

closePopup.addEventListener("click", () => {
    popup.style.display = "none";
})

notes.addEventListener("click", myFunction);
function myFunction(e) {
		var elems = document.querySelector(".active");
    if(elems !=null) {
      elems.classList.remove("active");
    }
    e.target.className = "active";
	}
 
function showNoteContent(noteId, content) {
            document.getElementById('text').hidden = false
            document.getElementById('cardContainer').hidden = true
            var textarea = document.getElementById("text");
            textarea.value = content;
            textarea.readOnly = false;
            textarea.dataset.noteId = noteId;
 }

// Function to fetch note content by note ID using AJAX
    function fetchNoteContent(noteId) {
        
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var noteContent = xhr.responseText;
                showNoteContent(noteId, noteContent);
              }
            };
            xhr.open("POST", "FetchNote", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.send("id=" + noteId);
        }
    
save.addEventListener("click",()=>{
//    console.log("Save")
    noteId = noteId
    content = textarea.value
    heading = window.location.hash.substring(1)
    email = localStorage.getItem('email');
    params = "noteId=" + encodeURIComponent(noteId) + "&heading=" + encodeURIComponent(heading) + "&content=" + encodeURIComponent(content) + "&email=" + encodeURIComponent(email);
 var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                noteContent = xhr.responseText;
//                window.location.href = "/noteworks/notes";
//                showNoteContent(noteId, noteContent);
              }
            };
            xhr.open("POST", "UpdateNote", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.send(params);
    
})

//Delete Note
for(let i=0;i<deleteNotes.length;i++){
    deleteNotes[i].addEventListener("click",()=>{
             noteId = noteId
    email = localStorage.getItem('email');
    params = "noteId=" + encodeURIComponent(noteId) + "&email=" + encodeURIComponent(email);
 var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                noteContent = xhr.responseText;
                window.location.href = "/noteworks/notes";
              }
            };
            xhr.open("POST", "DeleteNote", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.send(params);
    })
}

let noteId=0
function addNoteID(id){
    noteId=id
}

//Note Searching

// Function to create a card element
function createNoteCard(heading, text, note_id) {
    let card = document.createElement('div');
    card.className = 'card border-0';
    const note_body = text.substring(0,400)+"..."
    card.innerHTML = `
        <div class="position-relative"></div>
        <div class="card-body">
            <h5 class="card-title">${heading}</h5>
            <hr>
            <p class="card-text">${note_body}</p>
        </div>
        <div class="card-footer">
            <div class="media align-items-center">
                <div class="media-body"><a class="inactivecard-link text-uppercase" href="#${heading}" onclick="addNoteID(${note_id});fetchNoteContent(${note_id})">Read More</a></div>
                <div class="footerright">
                    <div class="tnlink3"><i class="fas fa-heart" aria-hidden="true"></i></div>
                    <div class="tnlink3"><i class="fas fa-share-nodes" aria-hidden="true"></i></div>
                </div>
            </div>
        </div>
    `;

    return card;
}

// Function to update the card container with data from the servlet
function updateNoteCardContainer(data) {
    var cardContainer = document.getElementById('cardContainer');

    // Clear existing cards
    cardContainer.innerHTML = '';

    // Create and append new cards based on the data received
    data.forEach(item => {
        var card = createNoteCard(item.heading, item.body, item.note_id);
        cardContainer.appendChild(card);
    });
}

//Search note form
function searchForm() {
    // Get values from the form
    let searchValue = document.getElementById('search-input').value;

    // Create a FormData object to send the form data
//    var formData = new FormData();
//    formData.append('search', searchValue);

    let formData = 'search='+searchValue
    

    // Make a fetch request
    fetch('./SearchNote', {
        method: 'POST',
        headers: {
       'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(result => {
        // Update the textarea with the response from the servlet
//        textarea.value = result;
        let data  = JSON.parse(result)
//        let data = result;
        document.getElementById('text').hidden = true
        document.getElementById('cardContainer').hidden = false
//        let responseData = [
//            { heading: 'Card 1', body: 'This is the content of Card 1.' },
//            { heading: 'Card 2', body: 'This is the content of Card 2.' },
            // Add more objects as needed
//        ];
        console.log(data)
        updateNoteCardContainer(data);
        
        // Create a card element
//        var card = document.createElement('div');
//        card.className = 'card';

        // Populate the card content
//        card.innerHTML = `
//            <h3>${data.heading}</h3>
//            <p>${data.heading}</p>
//        `;

//        let cardTitleElement = document.querySelector('.card-title');
//        let cardTextElement = document.querySelector('.card-text');
//        cardTitleElement.innerHTML = `${data.heading}`
//        cardTextElement.innerHTML = `${data.body}`

        // Append the card to the container
//        document.getElementById('cardContainer').appendChild(card);
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
    });
}

//Adding Markdown format
const editor = document.getElementById('text');
const preview = document.getElementById('preview')
const mdEdit = document.querySelector(".md-edit");
const mdPreview = document.querySelector(".md-preview");

function updatePreview() {
        editor.hidden=true;
        preview.hidden=false;
        const markdownText = editor.value;
       sanitizedHtml = SanitizeHtml(markdownText)
       preview.innerHTML = sanitizedHtml;
        //       preview.innerHTML = htmlText;
//       console.log(sanitizedHtml)
 }
 
 function SanitizeHtml(markdownText){
      const htmlText = marked.parse(markdownText);
      const sanitizedHtml = DOMPurify.sanitize(htmlText);
      return sanitizedHtml;
 }

edit=()=>{
  editor.hidden=false;
  preview.hidden=true;
}

mdEdit.addEventListener("click",()=>{
  contextMenu.style.visibility = "hidden"
  edit()
})

mdPreview.addEventListener("click",()=>{
  contextMenu.style.visibility = "hidden"
  updatePreview()
})

//Export
const pdfFile = `${window.location.href.split('#')[1]}.pdf`
const pdfOptions = {
//      margin: 10,
      filename: pdfFile,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
};

const pdfExp = document.querySelector(".pdfExp");

pdfExp.addEventListener('click',()=>{
//    alert(1)
//    const markdownText = editor.value;
//    sanitizedHtml = SanitizeHtml(markdownText)
      content = document.getElementById('preview')
      html2pdf(content,pdfOptions)
})

//AI Response
function showAIPopup() {
      var AIpopup = document.getElementById("myPopup");
      AIpopup.style.display = "block";
    }

    function hideAIPopup() {
      var AIpopup = document.getElementById("myPopup");
      AIpopup.style.display = "none";
    }

//Ai Work
const aiSummary = document.querySelector(".ai-summary");

aiSummary.addEventListener('click',()=>{
//    alert(text.value)
    let userText = selectText()
    let formData = "search=" + encodeURIComponent(userText) + "&askmethod=" + encodeURIComponent("shortNote");

    // Make a fetch request
    fetch('./NoteWorksAssistance', {
        method: 'POST',
        headers: {
       'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
    })
    .then(response => {
         if (response.status === 403) {
            alert("You are not subscribed")
            window.location.href = '/noteworks/payment';
        }
        else if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(result => {
        // Update the textarea with the response from the servlet
        AIContent.innerHTML = result;
        showAIPopup()
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
    });
})

const aiQuestions = document.querySelector(".ai-questions");

aiQuestions.addEventListener('click',()=>{
//    alert(text.value)
let userText = selectText()
    let formData = "search=" + encodeURIComponent(userText) + "&askmethod=" + encodeURIComponent("questions");

    // Make a fetch request
    fetch('./NoteWorksAssistance', {
        method: 'POST',
        headers: {
       'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
    })
    .then(response => {
         if (response.status === 403) {
            alert("You are not subscribed")
            window.location.href = '/noteworks/payment';
        }
        else if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(result => {
        // Update the textarea with the response from the servlet
        AIContent.innerHTML = result;
        showAIPopup()
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
    });
})

const aiAns = document.querySelector(".ai-ans");

aiAns.addEventListener('click',()=>{
//    alert(text.value)
let userText = selectText()
    let formData = "search=" + encodeURIComponent(userText) + "&askmethod=" + encodeURIComponent("answer");

    // Make a fetch request
    fetch('./NoteWorksAssistance', {
        method: 'POST',
        headers: {
       'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
    })
    .then(response => {
        if (response.status === 403) {
            alert("You are not subscribed")
            window.location.href = '/noteworks/payment';
        }
        else if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(result => {
        // Update the textarea with the response from the servlet
        AIContent.innerHTML = result;
        showAIPopup()
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
    });
})

//Undo Redo
const undoManager = new UndoRedo();

  textarea.addEventListener('input', () => {
    undoManager.add({
      undo: () => {
        textarea.value = undoManager.data.undo;
      },
      redo: () => {
        textarea.value = undoManager.data.redo;
      },
      data: {
        undo: textarea.value,
        redo: textarea.value,
      },
    });
  });

  document.addEventListener('keydown', (event) => {
    if (event.ctrlKey && event.key === 'z') {
      event.preventDefault();
      undoManager.undo();
    } else if (event.ctrlKey && event.key === 'y') {
      event.preventDefault();
      undoManager.redo();
    }
  });