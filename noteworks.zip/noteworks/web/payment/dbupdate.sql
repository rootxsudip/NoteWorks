desc users;

alter table users add subscription varchar2(5);

select * from users;

update users set subscription = 'True' where email = 'xeon550@gmail.com';

commit;

select * from notes WHERE user_email = 'sudiproy0007@gmail.com' order by note_id;