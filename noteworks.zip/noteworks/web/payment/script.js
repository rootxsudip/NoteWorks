
function submit(){
const name = document.getElementById('name').value
const email = document.getElementById('email').value
const address = document.getElementById('address').value
const city = document.getElementById('city').value
const zip = document.getElementById('zip').value
const creditCardName = document.getElementById('creditCardName').value
const cardNum = document.getElementById('card-num').value
const expiration = document.getElementById('expiration').value
const cvv = document.getElementById('cvv').value
//     Make a fetch request
    let formData = "name=" + encodeURIComponent(name)+"&email=" + encodeURIComponent(email)+"&address=" + encodeURIComponent(address)+"&city=" + encodeURIComponent(city)+"&zip=" + encodeURIComponent(zip)+"&creditCardName=" + encodeURIComponent(creditCardName)+"&cardNum=" + encodeURIComponent(cardNum)+"&expiration=" + encodeURIComponent(expiration)+"&cvv=" + encodeURIComponent(cvv) + "&username=" + encodeURIComponent(localStorage.getItem('email')) ;

    fetch('./subscription', {
        method: 'POST',
        headers: {
       'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
    })
    .then(response => {
         if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.text();
    })
    .then(result => {
//         Update the textarea with the response from the servlet
        alert(result)
        window.location.href="/noteworks/"
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
   });
 }

