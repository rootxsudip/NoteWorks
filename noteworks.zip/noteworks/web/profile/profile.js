const name = document.getElementById('fullName').value;
const email = document.getElementById('email').value;
const password = document.getElementById('password').value;
const image = document.getElementById('image');

let formData = "name=" + encodeURIComponent(name) + "&email=" + encodeURIComponent(email) + "&oldEmail=" + encodeURIComponent(localStorage.getItem('email')) + "&password=" + encodeURIComponent(password) ;
//Send post request
send=()=>{
const url = '/noteworks/profile/EditProfile'; // replace with your API endpoint

//const formData = new FormData();
//formData.append('name', name);
//formData.append('email', email);
//formData.append('password', password);
//formData.append('image', image);

// Assuming you have an input element with type="file" for the image
//const fileInput = document.getElementById('imageInput'); // replace with your actual input element ID
//const imageFile = fileInput.files[0];
//formData.append('image', imageFile);

fetch(url, {
   method: 'POST',
        headers: {
       'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: formData
})
  .then(response => response.text)
  .then(data => {
    console.log('Success:', data);
  })
  .catch(error => {
    console.error('Error:', error);
  });

}